import React from 'react'

const LoginSingup = () => {
    return (
        <div>
        
        </div>
    )
    }

export default LoginSingup
